
<strong>Copyright &copy; 2016 - <?php echo date('Y'); ?> <a target='_BLANK' href="#"> Swarakalibata Ci</a>.</strong> All rights reserved. 