<?php if(!defined('BASEPATH')) exit('Direct Access Not Allowed');

/* This Application Must Be Used With BootStrap 3 *  */
$config['full_tag_open'] = "";
$config['full_tag_close'] ="";
$config['num_tag_open'] = '<li>';
$config['num_tag_close'] = '</li>';
$config['cur_tag_open'] = "<li  class='active'>";
$config['cur_tag_close'] = "</li>";
$config['next_tag_open'] = "<li>";
$config['next_tagl_close'] = "</li>";
$config['prev_tag_open'] = "";
$config['prev_tagl_close'] = "";
$config['first_tag_open'] = "<li class='next'>";
$config['first_tagl_close'] = ">";
$config['last_tag_open'] = "<li class='next'>";
$config['last_tagl_close'] = "<";

// end of file Pagination.php 
// Location config/pagination.php 
// By @emanisof 