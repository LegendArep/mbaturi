
<strong>Copyright &copy; <?php echo date('Y'); ?> <a target='_BLANK' href="#"> Mbaturi Konsultan</a>.</strong> All rights reserved. 